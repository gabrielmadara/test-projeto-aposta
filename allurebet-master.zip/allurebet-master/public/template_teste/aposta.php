Aqui é selecionado após selecionar o jogo em aberto.

