<?php
/*
* Classe ajax: /ajax/
* 
*/
namespace controllers;
use core\Controller;
class ajaxController extends Controller {
	
	public function index(){
		$dados = array();
	}
	
}